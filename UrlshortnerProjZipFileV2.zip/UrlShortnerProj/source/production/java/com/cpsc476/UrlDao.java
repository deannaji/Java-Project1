package com.cpsc476;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.tree.RowMapper;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


public class UrlDao extends JdbcDaoSupport{
	//getting the application context
    private static ApplicationContext appctx = new ClassPathXmlApplicationContext("rootContext.xml");
    //getting "jdbcTemplate" bean, which gets the dataSource along with it.
    private static JdbcTemplate jdbcTemplate = (JdbcTemplate) appctx.getBean("JdbcTemplate");

    
    //UrlDao Methods(you just need to call them from any of the servlets, to get data:
    
    //This is just a testing method, no need for RowMapper here:
    public static String getEmployee(){
    	String name = (String) jdbcTemplate.queryForObject("Select firstName from employees where id=3", String.class);
        return name;
    }
    
    
    //This method is just a skeleton of what we might need(change it as you wish): 
    /*public static String getEmployeeData(){
    	
    	Url url = UrlDao.jdbcTemplate.queryForObject(
    	        "select longUrl, shortUrl, clicks from UrlsTable where id =1 ",
    	        new Object[]{1212L},
    	        new RowMapper<Url>() {
    	            public Url mapRow(ResultSet rs, int rowNum) throws SQLException {
    	                Url url = new Url();
    	                url.setLongUrl(rs.getString("longUrl"));
    	                url.setShortUrl(rs.getString("shortUrl"));
    	                return url;
    	            }
    	        });
    }*/
    
 
   
}//End of UrlDao class.
